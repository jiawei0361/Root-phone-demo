# Service controller script

resetprop -p --delete persist.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete persist.vendor.audio_hal.dsp_bit_width_enforce_mode
resetprop -p --delete media.resolution.limit.16bit
resetprop -p --delete media.resolution.limit.24bit
resetprop -p --delete media.resolution.limit.32bit
resetprop -p --delete media.resolution.limit.64bit

resetprop -p --delete debug.media.video.frc
resetprop -p --delete debug.media.video.vpp
resetprop -p --delete debug.media.video.aie
resetprop -p --delete debug.media.video.ais
resetprop -p --delete debug.media.video.style
resetprop -p --delete debug.media.video.ace
resetprop -p --delete debug.media.video.meeting

resetprop -p --delete persist.vendor.radio.diag_log_trriger

resetprop -p --delete ro.telephony.default_network

settings delete global hidden_api_policy
settings delete global hidden_api_policy_p_apps
settings delete global hidden_api_policy_pre_p_apps
settings delete global hidden_api_blacklist_exe

stop diag_mdlog_auto_start
stop tombstoned
rm -rf /data/anr
rm -rf /data/tombstones
rm -rf /data/*/tombstones
